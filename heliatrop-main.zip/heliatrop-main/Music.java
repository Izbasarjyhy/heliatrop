package com.izba.music.springapp1;

public interface Music {
     public String getSong();
}